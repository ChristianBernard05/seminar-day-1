x = int(input("Masukkan x :"))

for i in range(x,-200 - 1,-1):
   print(i,end= " ")
   