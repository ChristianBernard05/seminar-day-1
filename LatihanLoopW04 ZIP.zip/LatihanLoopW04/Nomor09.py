x = int(input("Masukkan x :"))

for i in range(1,x+1):
    
    print(("+"),(i+1)**2, end=",-")