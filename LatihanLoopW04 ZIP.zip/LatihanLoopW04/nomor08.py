x = int(input("Masukkan x :"))

fak = 1

for i in range(5,0,-1):
    fak *= i

print(fak)
