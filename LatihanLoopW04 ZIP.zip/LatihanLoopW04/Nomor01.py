x = int(input("Masukkan x :"))
for i in range(x):
    print ("INSTITUT INFORMATIKA INDONESIA")
    