x = int(input("Masukkan x :"))

for i in range(x):
    print((i+1)*5)
