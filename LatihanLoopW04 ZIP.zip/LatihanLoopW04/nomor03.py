x = int(input("Masukkan x :"))
for i in range(2,x,2):
    if i < x-2 :
        print (i,end=",")
    else :
        print(i)
