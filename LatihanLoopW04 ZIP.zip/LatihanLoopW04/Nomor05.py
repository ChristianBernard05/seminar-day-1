x = int(input("Masukkan x :"))

total = 0
for i in range(x):
    print("val",i+1,": ",end="")
    total = total + int(input())

total = total / x
print(total)
