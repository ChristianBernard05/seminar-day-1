x = int(input("Masukkan x :"))


print("Odd :")
for i in range(1,x,2):
    if i < x-2 :
        print(i, end=",")
    else :
        print(i)

print("Even :")
for i in range(2,x,2):
    if i < x-2 :
        print (i,end=",")
    else :
        print(i)
